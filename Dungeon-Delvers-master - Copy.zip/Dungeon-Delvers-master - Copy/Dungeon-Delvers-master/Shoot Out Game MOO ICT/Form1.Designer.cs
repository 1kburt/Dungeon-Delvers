﻿namespace Shoot_Out_Game_MOO_ICT
{
    partial class DungeonDelvers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DungeonDelvers));
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.labelRoom = new System.Windows.Forms.Label();
            this.labelFloor = new System.Windows.Forms.Label();
            this.labelGold = new System.Windows.Forms.Label();
            this.labelSouls = new System.Windows.Forms.Label();
            this.gun = new System.Windows.Forms.PictureBox();
            this.player = new System.Windows.Forms.PictureBox();
            this.goblin1 = new System.Windows.Forms.PictureBox();
            this.continueBtn = new System.Windows.Forms.PictureBox();
            this.slime3 = new System.Windows.Forms.PictureBox();
            this.slime2 = new System.Windows.Forms.PictureBox();
            this.slime1 = new System.Windows.Forms.PictureBox();
            this.heart3 = new System.Windows.Forms.PictureBox();
            this.heart2 = new System.Windows.Forms.PictureBox();
            this.heart1 = new System.Windows.Forms.PictureBox();
            this.rat3 = new System.Windows.Forms.PictureBox();
            this.rat2 = new System.Windows.Forms.PictureBox();
            this.rat1 = new System.Windows.Forms.PictureBox();
            this.bat3 = new System.Windows.Forms.PictureBox();
            this.bat2 = new System.Windows.Forms.PictureBox();
            this.bat1 = new System.Windows.Forms.PictureBox();
            this.chest = new System.Windows.Forms.PictureBox();
            this.basicDoor3 = new System.Windows.Forms.PictureBox();
            this.basicDoor2 = new System.Windows.Forms.PictureBox();
            this.basicDoor1 = new System.Windows.Forms.PictureBox();
            this.basicDoor = new System.Windows.Forms.PictureBox();
            this.stairs = new System.Windows.Forms.PictureBox();
            this.skeleton3 = new System.Windows.Forms.PictureBox();
            this.skeleton2 = new System.Windows.Forms.PictureBox();
            this.skeleton1 = new System.Windows.Forms.PictureBox();
            this.deathScreen = new System.Windows.Forms.PictureBox();
            this.goblin1Gun = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.gun)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goblin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.continueBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slime3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slime2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slime1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rat3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rat2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rat1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bat3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bat2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bat1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDoor3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDoor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDoor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stairs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skeleton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skeleton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skeleton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deathScreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goblin1Gun)).BeginInit();
            this.SuspendLayout();
            // 
            // GameTimer
            // 
            this.GameTimer.Enabled = true;
            this.GameTimer.Interval = 20;
            this.GameTimer.Tick += new System.EventHandler(this.MainTimerEvent);
            // 
            // labelRoom
            // 
            this.labelRoom.AutoSize = true;
            this.labelRoom.BackColor = System.Drawing.Color.White;
            this.labelRoom.Location = new System.Drawing.Point(15, 12);
            this.labelRoom.Name = "labelRoom";
            this.labelRoom.Size = new System.Drawing.Size(38, 13);
            this.labelRoom.TabIndex = 10;
            this.labelRoom.Text = "Room:";
            // 
            // labelFloor
            // 
            this.labelFloor.AutoSize = true;
            this.labelFloor.BackColor = System.Drawing.Color.White;
            this.labelFloor.Location = new System.Drawing.Point(15, 26);
            this.labelFloor.Name = "labelFloor";
            this.labelFloor.Size = new System.Drawing.Size(33, 13);
            this.labelFloor.TabIndex = 11;
            this.labelFloor.Text = "Floor:";
            // 
            // labelGold
            // 
            this.labelGold.AutoSize = true;
            this.labelGold.BackColor = System.Drawing.Color.White;
            this.labelGold.Location = new System.Drawing.Point(15, 40);
            this.labelGold.Name = "labelGold";
            this.labelGold.Size = new System.Drawing.Size(32, 13);
            this.labelGold.TabIndex = 12;
            this.labelGold.Text = "Gold:";
            // 
            // labelSouls
            // 
            this.labelSouls.AutoSize = true;
            this.labelSouls.BackColor = System.Drawing.Color.White;
            this.labelSouls.Location = new System.Drawing.Point(15, 54);
            this.labelSouls.Name = "labelSouls";
            this.labelSouls.Size = new System.Drawing.Size(32, 13);
            this.labelSouls.TabIndex = 23;
            this.labelSouls.Text = "Gold:";
            // 
            // gun
            // 
            this.gun.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.spaceGun;
            this.gun.Location = new System.Drawing.Point(368, 295);
            this.gun.Name = "gun";
            this.gun.Size = new System.Drawing.Size(59, 44);
            this.gun.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gun.TabIndex = 33;
            this.gun.TabStop = false;
            // 
            // player
            // 
            this.player.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.playerRight21;
            this.player.Location = new System.Drawing.Point(400, 445);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(75, 95);
            this.player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player.TabIndex = 2;
            this.player.TabStop = false;
            // 
            // goblin1
            // 
            this.goblin1.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.goblin2;
            this.goblin1.Location = new System.Drawing.Point(677, 460);
            this.goblin1.Name = "goblin1";
            this.goblin1.Size = new System.Drawing.Size(70, 80);
            this.goblin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.goblin1.TabIndex = 32;
            this.goblin1.TabStop = false;
            // 
            // continueBtn
            // 
            this.continueBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.continueBtn.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources._continue;
            this.continueBtn.Location = new System.Drawing.Point(294, 440);
            this.continueBtn.Name = "continueBtn";
            this.continueBtn.Size = new System.Drawing.Size(340, 70);
            this.continueBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.continueBtn.TabIndex = 30;
            this.continueBtn.TabStop = false;
            this.continueBtn.Click += new System.EventHandler(this.continueBtn_Click);
            // 
            // slime3
            // 
            this.slime3.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.StretchedSlimeBlueL;
            this.slime3.Location = new System.Drawing.Point(570, 183);
            this.slime3.Margin = new System.Windows.Forms.Padding(2);
            this.slime3.Name = "slime3";
            this.slime3.Size = new System.Drawing.Size(64, 52);
            this.slime3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slime3.TabIndex = 26;
            this.slime3.TabStop = false;
            // 
            // slime2
            // 
            this.slime2.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.StretchedSlimeBlueL;
            this.slime2.Location = new System.Drawing.Point(477, 183);
            this.slime2.Margin = new System.Windows.Forms.Padding(2);
            this.slime2.Name = "slime2";
            this.slime2.Size = new System.Drawing.Size(64, 52);
            this.slime2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slime2.TabIndex = 25;
            this.slime2.TabStop = false;
            // 
            // slime1
            // 
            this.slime1.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.StretchedSlimeBlueL;
            this.slime1.Location = new System.Drawing.Point(385, 183);
            this.slime1.Margin = new System.Windows.Forms.Padding(2);
            this.slime1.Name = "slime1";
            this.slime1.Size = new System.Drawing.Size(64, 52);
            this.slime1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slime1.TabIndex = 24;
            this.slime1.TabStop = false;
            // 
            // heart3
            // 
            this.heart3.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.Heart;
            this.heart3.Location = new System.Drawing.Point(89, 621);
            this.heart3.Margin = new System.Windows.Forms.Padding(2);
            this.heart3.Name = "heart3";
            this.heart3.Size = new System.Drawing.Size(33, 29);
            this.heart3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heart3.TabIndex = 22;
            this.heart3.TabStop = false;
            // 
            // heart2
            // 
            this.heart2.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.Heart;
            this.heart2.Location = new System.Drawing.Point(51, 621);
            this.heart2.Margin = new System.Windows.Forms.Padding(2);
            this.heart2.Name = "heart2";
            this.heart2.Size = new System.Drawing.Size(33, 29);
            this.heart2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heart2.TabIndex = 21;
            this.heart2.TabStop = false;
            // 
            // heart1
            // 
            this.heart1.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.Heart;
            this.heart1.Location = new System.Drawing.Point(13, 621);
            this.heart1.Margin = new System.Windows.Forms.Padding(2);
            this.heart1.Name = "heart1";
            this.heart1.Size = new System.Drawing.Size(33, 29);
            this.heart1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heart1.TabIndex = 20;
            this.heart1.TabStop = false;
            // 
            // rat3
            // 
            this.rat3.Image = ((System.Drawing.Image)(resources.GetObject("rat3.Image")));
            this.rat3.Location = new System.Drawing.Point(584, 440);
            this.rat3.Name = "rat3";
            this.rat3.Size = new System.Drawing.Size(87, 46);
            this.rat3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rat3.TabIndex = 18;
            this.rat3.TabStop = false;
            // 
            // rat2
            // 
            this.rat2.Image = ((System.Drawing.Image)(resources.GetObject("rat2.Image")));
            this.rat2.Location = new System.Drawing.Point(654, 285);
            this.rat2.Name = "rat2";
            this.rat2.Size = new System.Drawing.Size(87, 46);
            this.rat2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rat2.TabIndex = 17;
            this.rat2.TabStop = false;
            // 
            // rat1
            // 
            this.rat1.Image = ((System.Drawing.Image)(resources.GetObject("rat1.Image")));
            this.rat1.Location = new System.Drawing.Point(454, 377);
            this.rat1.Name = "rat1";
            this.rat1.Size = new System.Drawing.Size(87, 46);
            this.rat1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rat1.TabIndex = 16;
            this.rat1.TabStop = false;
            // 
            // bat3
            // 
            this.bat3.Image = ((System.Drawing.Image)(resources.GetObject("bat3.Image")));
            this.bat3.Location = new System.Drawing.Point(250, 270);
            this.bat3.Name = "bat3";
            this.bat3.Size = new System.Drawing.Size(89, 36);
            this.bat3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bat3.TabIndex = 15;
            this.bat3.TabStop = false;
            // 
            // bat2
            // 
            this.bat2.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.batDown;
            this.bat2.Location = new System.Drawing.Point(360, 295);
            this.bat2.Name = "bat2";
            this.bat2.Size = new System.Drawing.Size(89, 36);
            this.bat2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bat2.TabIndex = 14;
            this.bat2.TabStop = false;
            // 
            // bat1
            // 
            this.bat1.Image = ((System.Drawing.Image)(resources.GetObject("bat1.Image")));
            this.bat1.Location = new System.Drawing.Point(506, 286);
            this.bat1.Name = "bat1";
            this.bat1.Size = new System.Drawing.Size(89, 36);
            this.bat1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bat1.TabIndex = 13;
            this.bat1.TabStop = false;
            // 
            // chest
            // 
            this.chest.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.OpenChest;
            this.chest.Location = new System.Drawing.Point(447, 315);
            this.chest.Name = "chest";
            this.chest.Size = new System.Drawing.Size(70, 55);
            this.chest.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.chest.TabIndex = 19;
            this.chest.TabStop = false;
            // 
            // basicDoor3
            // 
            this.basicDoor3.Image = ((System.Drawing.Image)(resources.GetObject("basicDoor3.Image")));
            this.basicDoor3.InitialImage = ((System.Drawing.Image)(resources.GetObject("basicDoor3.InitialImage")));
            this.basicDoor3.Location = new System.Drawing.Point(432, 1);
            this.basicDoor3.Name = "basicDoor3";
            this.basicDoor3.Size = new System.Drawing.Size(65, 100);
            this.basicDoor3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basicDoor3.TabIndex = 6;
            this.basicDoor3.TabStop = false;
            // 
            // basicDoor2
            // 
            this.basicDoor2.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.DoorClosed;
            this.basicDoor2.InitialImage = ((System.Drawing.Image)(resources.GetObject("basicDoor2.InitialImage")));
            this.basicDoor2.Location = new System.Drawing.Point(432, 560);
            this.basicDoor2.Name = "basicDoor2";
            this.basicDoor2.Size = new System.Drawing.Size(65, 100);
            this.basicDoor2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basicDoor2.TabIndex = 5;
            this.basicDoor2.TabStop = false;
            // 
            // basicDoor1
            // 
            this.basicDoor1.Image = ((System.Drawing.Image)(resources.GetObject("basicDoor1.Image")));
            this.basicDoor1.InitialImage = ((System.Drawing.Image)(resources.GetObject("basicDoor1.InitialImage")));
            this.basicDoor1.Location = new System.Drawing.Point(858, 270);
            this.basicDoor1.Name = "basicDoor1";
            this.basicDoor1.Size = new System.Drawing.Size(65, 100);
            this.basicDoor1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basicDoor1.TabIndex = 4;
            this.basicDoor1.TabStop = false;
            // 
            // basicDoor
            // 
            this.basicDoor.Image = ((System.Drawing.Image)(resources.GetObject("basicDoor.Image")));
            this.basicDoor.InitialImage = ((System.Drawing.Image)(resources.GetObject("basicDoor.InitialImage")));
            this.basicDoor.Location = new System.Drawing.Point(1, 270);
            this.basicDoor.Name = "basicDoor";
            this.basicDoor.Size = new System.Drawing.Size(65, 100);
            this.basicDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basicDoor.TabIndex = 3;
            this.basicDoor.TabStop = false;
            // 
            // stairs
            // 
            this.stairs.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.staircase;
            this.stairs.Location = new System.Drawing.Point(213, 334);
            this.stairs.Name = "stairs";
            this.stairs.Size = new System.Drawing.Size(83, 79);
            this.stairs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stairs.TabIndex = 7;
            this.stairs.TabStop = false;
            // 
            // skeleton3
            // 
            this.skeleton3.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.SkeletonUpR;
            this.skeleton3.Location = new System.Drawing.Point(302, 460);
            this.skeleton3.Name = "skeleton3";
            this.skeleton3.Size = new System.Drawing.Size(78, 120);
            this.skeleton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.skeleton3.TabIndex = 29;
            this.skeleton3.TabStop = false;
            // 
            // skeleton2
            // 
            this.skeleton2.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.SkeletonUpR;
            this.skeleton2.Location = new System.Drawing.Point(188, 430);
            this.skeleton2.Name = "skeleton2";
            this.skeleton2.Size = new System.Drawing.Size(78, 120);
            this.skeleton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.skeleton2.TabIndex = 28;
            this.skeleton2.TabStop = false;
            // 
            // skeleton1
            // 
            this.skeleton1.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.SkeletonUpR;
            this.skeleton1.Location = new System.Drawing.Point(104, 398);
            this.skeleton1.Name = "skeleton1";
            this.skeleton1.Size = new System.Drawing.Size(78, 120);
            this.skeleton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.skeleton1.TabIndex = 27;
            this.skeleton1.TabStop = false;
            // 
            // deathScreen
            // 
            this.deathScreen.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.deathScreen;
            this.deathScreen.Location = new System.Drawing.Point(-8, -30);
            this.deathScreen.Name = "deathScreen";
            this.deathScreen.Size = new System.Drawing.Size(940, 700);
            this.deathScreen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.deathScreen.TabIndex = 31;
            this.deathScreen.TabStop = false;
            this.deathScreen.Visible = false;
            // 
            // goblin1Gun
            // 
            this.goblin1Gun.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.spaceGun;
            this.goblin1Gun.Location = new System.Drawing.Point(752, 490);
            this.goblin1Gun.Name = "goblin1Gun";
            this.goblin1Gun.Size = new System.Drawing.Size(59, 44);
            this.goblin1Gun.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.goblin1Gun.TabIndex = 34;
            this.goblin1Gun.TabStop = false;
            // 
            // DungeonDelvers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(924, 661);
            this.Controls.Add(this.gun);
            this.Controls.Add(this.player);
            this.Controls.Add(this.goblin1Gun);
            this.Controls.Add(this.goblin1);
            this.Controls.Add(this.continueBtn);
            this.Controls.Add(this.slime3);
            this.Controls.Add(this.slime2);
            this.Controls.Add(this.slime1);
            this.Controls.Add(this.labelSouls);
            this.Controls.Add(this.heart3);
            this.Controls.Add(this.heart2);
            this.Controls.Add(this.heart1);
            this.Controls.Add(this.rat3);
            this.Controls.Add(this.rat2);
            this.Controls.Add(this.rat1);
            this.Controls.Add(this.bat3);
            this.Controls.Add(this.bat2);
            this.Controls.Add(this.bat1);
            this.Controls.Add(this.labelGold);
            this.Controls.Add(this.labelFloor);
            this.Controls.Add(this.labelRoom);
            this.Controls.Add(this.chest);
            this.Controls.Add(this.basicDoor3);
            this.Controls.Add(this.basicDoor2);
            this.Controls.Add(this.basicDoor1);
            this.Controls.Add(this.basicDoor);
            this.Controls.Add(this.stairs);
            this.Controls.Add(this.skeleton3);
            this.Controls.Add(this.skeleton2);
            this.Controls.Add(this.skeleton1);
            this.Controls.Add(this.deathScreen);
            this.Name = "DungeonDelvers";
            this.Text = "Dungeon Delvers";
            this.Load += new System.EventHandler(this.DungeonDelvers_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyIsDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyIsUp);
            ((System.ComponentModel.ISupportInitialize)(this.gun)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goblin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.continueBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slime3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slime2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slime1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rat3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rat2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rat1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bat3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bat2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bat1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDoor3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDoor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDoor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stairs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skeleton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skeleton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skeleton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deathScreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goblin1Gun)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.Timer GameTimer;
        private System.Windows.Forms.PictureBox basicDoor;
        private System.Windows.Forms.PictureBox basicDoor1;
        private System.Windows.Forms.PictureBox basicDoor2;
        private System.Windows.Forms.PictureBox basicDoor3;
        private System.Windows.Forms.Label labelRoom;
        private System.Windows.Forms.Label labelFloor;
        private System.Windows.Forms.Label labelGold;
        private System.Windows.Forms.PictureBox bat1;
        private System.Windows.Forms.PictureBox bat2;
        private System.Windows.Forms.PictureBox bat3;
        private System.Windows.Forms.PictureBox rat1;
        private System.Windows.Forms.PictureBox rat2;
        private System.Windows.Forms.PictureBox rat3;
        private System.Windows.Forms.PictureBox stairs;
        private System.Windows.Forms.PictureBox chest;
        private System.Windows.Forms.PictureBox heart1;
        private System.Windows.Forms.PictureBox heart2;
        private System.Windows.Forms.PictureBox heart3;
        private System.Windows.Forms.Label labelSouls;
        private System.Windows.Forms.PictureBox slime1;
        private System.Windows.Forms.PictureBox slime2;
        private System.Windows.Forms.PictureBox slime3;
        private System.Windows.Forms.PictureBox skeleton1;
        private System.Windows.Forms.PictureBox skeleton2;
        private System.Windows.Forms.PictureBox skeleton3;
        private System.Windows.Forms.PictureBox continueBtn;
        private System.Windows.Forms.PictureBox deathScreen;
        private System.Windows.Forms.PictureBox goblin1;
        private System.Windows.Forms.PictureBox gun;
        private System.Windows.Forms.PictureBox goblin1Gun;
    }
}

