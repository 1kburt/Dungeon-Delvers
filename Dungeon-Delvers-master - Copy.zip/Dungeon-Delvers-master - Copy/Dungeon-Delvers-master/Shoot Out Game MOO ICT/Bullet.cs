﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Drawing;
using System.Windows.Forms;

namespace Shoot_Out_Game_MOO_ICT
{
    class Bullet
    {
        public string direction;
        public string shooter;
        public int bulletLeft;
        public int bulletTop;
        public string gunType = "spacegun"; //change later

        private int speed = 15;
        private PictureBox bullet = new PictureBox();
        private Timer bulletTimer = new Timer();


        public void MakeBullet(Form form)
        {


            if (gunType == "spacegun")
            {
                bullet.Image = Image.FromFile("images/spaceGunBullet.png");
                bullet.Size = new Size(10, 10);
            }
            //bullet.Size = new Size(5, 5);
            bullet.Tag = "bullet";
            bullet.Left = bulletLeft;
            bullet.Top = bulletTop;
            bullet.BringToFront();
            form.Controls.Add(bullet);
            if (shooter == "goblin1" || shooter == "goblin2" || shooter == "goblin3")
            {
                DungeonDelvers.BulletHitsPlayer = true;
            }
            else if (shooter == "player")
            {

            }

            bulletTimer.Interval = speed;
            bulletTimer.Tick += new EventHandler(BulletTimerEvent);
            bulletTimer.Start();

        }

        private void BulletTimerEvent(object sender, EventArgs e)
        {
            if (direction == "rightup")
            {
                bullet.Top -= speed;
                bullet.Left += speed;
            }
            if (direction == "leftup")
            {
                bullet.Top -= speed;
                bullet.Left -= speed;
            }
            if (direction == "rightdown")
            {
                bullet.Top += speed;
                bullet.Left += speed;
            }
            if(direction == "leftdown")
            {
                bullet.Top += speed;
                bullet.Left -= speed;
            }
            if (direction == "left")
            {
                bullet.Left -= speed;
            }

            if (direction == "right")
            {
                bullet.Left += speed;
            }

            if (direction == "up")
            {
                bullet.Top -= speed;
            }

            if (direction == "down")
            {
                bullet.Top += speed;
            }


            if (bullet.Left < 10 || bullet.Left > 860 || bullet.Top < 10 || bullet.Top > 600)
            {
                bulletTimer.Stop();
                bulletTimer.Dispose();
                bullet.Dispose();
                bulletTimer = null;
                bullet = null;
            }



        }



    }
}
