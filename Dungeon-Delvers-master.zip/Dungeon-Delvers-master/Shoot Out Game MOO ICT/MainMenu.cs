﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shoot_Out_Game_MOO_ICT
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();

        }
        bool respawn;
        private void continueBtn_Click(object sender, EventArgs e)
        {
            soulsMenu form2 = new soulsMenu();
            form2.Show();
            this.Close();
            using (StreamWriter writer = new StreamWriter("quit.csv"))
            {
                writer.Write(string.Empty); // This clears the file
                writer.WriteLine("false");
            }
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            using (StreamWriter writer = new StreamWriter("quit.csv"))
            {
                writer.Write(string.Empty); // This clears the file
                writer.WriteLine("true");
            }
        }

        private void newGameBtn_Click(object sender, EventArgs e)
        {
            using (StreamWriter first = new StreamWriter("firstRun.csv"))
            {
                first.Write(string.Empty); // This clears the file
                first.Write(false);
            }
            using (StreamWriter writer = new StreamWriter("quit.csv"))
            {
                writer.Write(string.Empty); // This clears the file
                writer.WriteLine("false");
            }
            //clear everything
            using (StreamWriter writer = new StreamWriter("souls.csv"))
            {
                writer.Write(string.Empty); // This clears the file
            }
            using (StreamWriter writer = new StreamWriter("upgrades.csv"))
            {
                writer.Write(string.Empty); // This clears the file
            }
            //open main form
            using (StreamWriter writer = new StreamWriter("respawn.csv"))
            {
                writer.Write(string.Empty); // This clears the file
                writer.WriteLine("true");
            }
            this.Close();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            bool firstRun;
            string anyUpgrades;
            bool noUpgrades = false;
            string souls;
            bool noSouls = false;
            using (StreamReader reader = new StreamReader("firstRun.csv"))
            {
                firstRun = bool.Parse(reader.ReadToEnd());
            }
            using (StreamReader reader = new StreamReader("upgrades.csv"))
            {
                anyUpgrades = reader.ReadToEnd();
                if (anyUpgrades == null)
                {
                    noUpgrades = true;
                }
            }
            using (StreamReader reader = new StreamReader("souls.csv"))
            {
                // Read the variable content and assign it to souls variable
                souls = reader.ReadToEnd();
                if (souls == null || souls == "")
                {
                    noSouls=true;
                }
            }
            if (noSouls)
            {
                continueBtn.Enabled = false;
                continueBtn.Hide();
                exitBtn.Top = 420;
                tutorialBtn.Top = 320;
            }
            else
            {
                continueBtn.Enabled = true;
                continueBtn.Show();
                exitBtn.Top = 520;
                tutorialBtn.Top = 420;
            }
        }

        private void tutorialBtn_Click(object sender, EventArgs e)
        {
            Tutorial tutorial = new Tutorial();
            tutorial.Show();
            this.Close();
        }
    }
}
