﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shoot_Out_Game_MOO_ICT
{
    public partial class soulsMenu : Form
    {
        int souls;
        string items;
        List<string> upgrades = new List<string>();
        int healthBoostLevel = 0;
        int attackBoostLevel = 0;
        int luckyStartLevel = 0;
        int iFrameLevel = 0;
        Random randNum = new Random();
        int positiveMessage;
        int avoidNumber;
        bool won;
        public soulsMenu()
        {
            InitializeComponent();
            speechBubble.Hide();
        }

        private void soulsMenu_Load(object sender, EventArgs e)
        {
            using (StreamReader reader = new StreamReader("win.csv"))
            {
                // Read the variable content and assign it to souls variable
                won = bool.Parse(reader.ReadToEnd());
            }
            PositiveMessage();
            //puts all upgrades from file into a list
            using (StreamReader reader = new StreamReader("upgrades.csv"))
            {
                items = reader.ReadToEnd();
                for (int i = 0; i < 5; i++)
                {
                    if (items.Contains($"lvl{i}healthBoost"))
                    {
                        upgrades.Add($"lvl{i}healthBoost");
                    }
                    if (items.Contains($"lvl{i}attackBoost"))
                    {
                        upgrades.Add($"lvl{i}attackBoost");
                    }
                    if (items.Contains($"lvl{i}luckyStart"))
                    {
                        upgrades.Add($"lvl{i}luckyStart");
                    }
                    if (items.Contains($"lvl{i}invincibility"))
                    {
                        upgrades.Add($"lvl{i}invincibility");
                    }
                }
            }
            //clears the upgrades file
            using (StreamWriter writer = new StreamWriter("upgrades.csv"))
            {
                writer.Write(string.Empty); // This clears the file
            }
            //sets souls equal to the number of souls collected (in csv file)
            using (StreamReader reader = new StreamReader("souls.csv"))
            {
                // Read the variable content and assign it to souls variable
                souls = int.Parse(reader.ReadToEnd());
            }
            //set label to display number of souls    
            labelSouls.Text = (souls.ToString());
            //healthBoost
            if (upgrades.Contains("lvl1healthBoost"))
            {
                healthBoost.Image = Image.FromFile("images/lvl1healthBoost.png");
                healthBoostLevel = 1;
            }
            else if (upgrades.Contains("lvl2healthBoost"))
            {
                healthBoost.Image = Image.FromFile("images/lvl2healthBoost.png");
                healthBoostLevel = 2;
            }
            else if (upgrades.Contains("lvl3healthBoost"))
            {
                healthBoost.Image = Image.FromFile("images/lvl3healthBoost.png");
                healthBoostLevel = 3;
            }
            else if (upgrades.Contains("lvl4healthBoost"))
            {
                healthBoost.Image = Image.FromFile("images/lvl4healthBoost.png");
                healthBoostLevel = 4;
            }
            else
            {
                healthBoost.Image = Image.FromFile("images/healthBoost.png");
            }

            //attackBoost
            if (upgrades.Contains("lvl1attackBoost"))
            {
                attackBoost.Image = Image.FromFile("images/lvl1attackBoost.png");
                attackBoostLevel = 1;
            }
            else if (upgrades.Contains("lvl2attackBoost"))
            {
                attackBoost.Image = Image.FromFile("images/lvl2attackBoost.png");
                attackBoostLevel = 2;
            }
            else if (upgrades.Contains("lvl3attackBoost"))
            {
                attackBoost.Image = Image.FromFile("images/lvl3attackBoost.png");
                attackBoostLevel = 3;
            }
            else if (upgrades.Contains("lvl4attackBoost"))
            {
                attackBoost.Image = Image.FromFile("images/lvl4attackBoost.png");
                attackBoostLevel = 4;
            }
            else
            {
                attackBoost.Image = Image.FromFile("images/attackBoost.png");
            }

            //luckyStart
            if (upgrades.Contains("lvl1luckyStart"))
            {
                luckyStart.Image = Image.FromFile("images/lvl1luckyStart.png");
                luckyStartLevel = 1;
            }
            else if (upgrades.Contains("lvl2luckyStart"))
            {
                luckyStart.Image = Image.FromFile("images/lvl2luckyStart.png");
                luckyStartLevel = 2;
            }
            else if (upgrades.Contains("lvl3luckyStart"))
            {
                luckyStart.Image = Image.FromFile("images/lvl3luckyStart.png");
                luckyStartLevel = 3;
            }
            else if (upgrades.Contains("lvl4luckyStart"))
            {
                luckyStart.Image = Image.FromFile("images/lvl4luckyStart.png");
                luckyStartLevel = 4;
            }
            else
            {
                luckyStart.Image = Image.FromFile("images/luckyStart.png");
            }

            //iFrames
            if (upgrades.Contains("lvl1invincibility"))
            {
                invincibility.Image = Image.FromFile("images/lvl1invincibility.png");
                iFrameLevel = 1;
            }
            else if (upgrades.Contains("lvl2invincibility"))
            {
                invincibility.Image = Image.FromFile("images/lvl2invincibility.png");
                iFrameLevel = 2;
            }
            else if (upgrades.Contains("lvl3invincibility"))
            {
                invincibility.Image = Image.FromFile("images/lvl3invincibility.png");
                iFrameLevel = 3;
            }
            else if (upgrades.Contains("lvl4invincibility"))
            {
                invincibility.Image = Image.FromFile("images/lvl4invincibility.png");
                iFrameLevel = 4;
            }
            else
            {
                invincibility.Image = Image.FromFile("images/invincibility.png");
            }
        }

        private void speechBubble_Click(object sender, EventArgs e)
        {
            speechBubble.Hide();
        }

        private void reaper_Click(object sender, EventArgs e)
        {
            PositiveMessage();
        }
        private void PositiveMessage()
        {
            if (!won)
            {
                avoidNumber = positiveMessage;
                do
                {
                    positiveMessage = randNum.Next(1, 3 + 1);
                } while (positiveMessage == avoidNumber);
                speechBubble.Show();
                speechBubble.Image = Image.FromFile($"speech/positive{positiveMessage}.gif");
            }
            else
            {
                speechBubble.Show();
                speechBubble.Image = Image.FromFile("speech/alwaysKnew.gif");
            }
        }

        private void attackBoost_Click(object sender, EventArgs e)
        {
            if (attackBoostLevel < 4)
            {
                //check if player can afford item
                if (souls >= attackBoostLevel + 2)
                {
                    //add attackBoost to upgrades
                    if (attackBoostLevel == 0)
                    {
                        souls -= 2;
                        upgrades.Add("lvl1attackBoost");
                        attackBoostLevel++;
                        attackBoost.Image = Image.FromFile($"images/lvl{attackBoostLevel}attackBoost.png");
                    }
                    else
                    {
                        //deduct souls
                        souls -= attackBoostLevel + 2;
                        //removes upgrade from list
                        upgrades.RemoveAt(upgrades.IndexOf($"lvl{attackBoostLevel}attackBoost"));
                        //adds new upgrade to list
                        upgrades.Add($"lvl{attackBoostLevel + 1}attackBoost");
                        attackBoostLevel++;
                        attackBoost.Image = Image.FromFile($"images/lvl{attackBoostLevel}attackBoost.png");
                    }
                    labelSouls.Text = (souls.ToString());
                }
                else
                {
                    CannotAfford();
                }
            }
        }
        private void healthBoost_Click(object sender, EventArgs e)
        {
            if (healthBoostLevel < 4)
            {
                //check if player can afford item
                if (souls >= healthBoostLevel + 2)
                {
                    //add healthBoost to upgrades
                    if (healthBoostLevel == 0)
                    {
                        souls -= 2;
                        upgrades.Add("lvl1healthBoost");
                        healthBoostLevel++;
                        healthBoost.Image = Image.FromFile($"images/lvl{healthBoostLevel}healthBoost.png");
                    }
                    else
                    {
                        //deduct souls
                        souls -= healthBoostLevel + 2;
                        //removes upgrade from list
                        upgrades.RemoveAt(upgrades.IndexOf($"lvl{healthBoostLevel}healthBoost"));
                        //adds new upgrade to list
                        upgrades.Add($"lvl{healthBoostLevel + 1}healthBoost");
                        healthBoostLevel++;
                        healthBoost.Image = Image.FromFile($"images/lvl{healthBoostLevel}healthBoost.png");
                    }
                    labelSouls.Text = (souls.ToString());
                }
                else
                {
                    CannotAfford();
                }
            }
        }
        private void luckyStart_Click(object sender, EventArgs e)
        {
            if (luckyStartLevel < 4)
            {
                //check if player can afford item
                if (souls >= luckyStartLevel + 3)
                {
                    //add luckyStart to upgrades
                    if (luckyStartLevel == 0)
                    {
                        souls -= 3;
                        upgrades.Add("lvl1luckyStart");
                        luckyStartLevel++;
                        luckyStart.Image = Image.FromFile($"images/lvl{luckyStartLevel}luckyStart.png");
                    }
                    else
                    {
                        //deduct souls
                        souls -= luckyStartLevel + 2;
                        //removes upgrade from list
                        upgrades.RemoveAt(upgrades.IndexOf($"lvl{luckyStartLevel}luckyStart"));
                        //adds new upgrade to list
                        upgrades.Add($"lvl{luckyStartLevel + 1}luckyStart");
                        luckyStartLevel++;
                        luckyStart.Image = Image.FromFile($"images/lvl{luckyStartLevel}luckyStart.png");
                    }
                    labelSouls.Text = (souls.ToString());
                }
                else
                {
                    CannotAfford();
                }
            }
        }

        private void invincibility_Click(object sender, EventArgs e)
        {
            if (iFrameLevel < 4)
            {
                //check if player can afford item
                if (souls >= (iFrameLevel+1) * 2 )
                {
                    //add luckyStart to upgrades
                    if (iFrameLevel == 0)
                    {
                        souls -= 2;
                        upgrades.Add("lvl1invincibility");
                        iFrameLevel++;
                        invincibility.Image = Image.FromFile($"images/lvl{iFrameLevel}invincibility.png");
                    }
                    else
                    {
                        //deduct souls
                        souls -= (iFrameLevel + 1) * 2;
                        //removes upgrade from list
                        upgrades.RemoveAt(upgrades.IndexOf($"lvl{iFrameLevel}invincibility"));
                        //adds new upgrade to list
                        upgrades.Add($"lvl{iFrameLevel + 1}invincibility");
                        iFrameLevel++;
                        invincibility.Image = Image.FromFile($"images/lvl{iFrameLevel}invincibility.png");
                    }
                    labelSouls.Text = (souls.ToString());
                }
                else
                {
                    CannotAfford();
                }
            }
        }
        private void CannotAfford()
        {
            //player can't afford item
            speechBubble.Show();
            speechBubble.Image = Image.FromFile("speech/cannotAfford.gif");
        }

        private void continueBtn_Click(object sender, EventArgs e)
        {
            using (StreamWriter first = new StreamWriter("firstRun.csv"))
            {
                first.Write(string.Empty); // This clears the file
                first.Write(false);
            }
            using (StreamWriter writer = new StreamWriter("respawn.csv"))
            {

                writer.WriteLine(true);
            }
            //takes list of upgrades and puts it into a csv file
            using (StreamWriter writer = new StreamWriter("upgrades.csv"))
            {

                for (int i = 0; i < upgrades.Count; i++)
                {
                    writer.Write(upgrades[i]);
                }
            }
            //Clears upgrades to be ready for next death
            upgrades.Clear();
            //clears souls
            using (StreamWriter writer = new StreamWriter("souls.csv"))
            {
                writer.Write(string.Empty); // This clears the file
            }

            //open main form
            using (StreamWriter writer = new StreamWriter("respawn.csv"))
            {
                writer.Write(string.Empty); // This clears the file
                writer.WriteLine("true");
            }
            this.Close();
        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            //takes list of upgrades and puts it into a csv file
            using (StreamWriter writer = new StreamWriter("upgrades.csv"))
            {

                for (int i = 0; i < upgrades.Count; i++)
                {
                    writer.Write(upgrades[i]);
                }
            }
            //Clears upgrades to be ready for next death
            upgrades.Clear();
            //clears souls
            using (StreamWriter writer = new StreamWriter("souls.csv"))
            {
                writer.Write(string.Empty); // This clears the file
                writer.WriteLine(souls);
            }
            //open main menu
            MainMenu menu = new MainMenu();
            menu.Show();
            this.Close();
        }
    }
}
