﻿namespace Shoot_Out_Game_MOO_ICT
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tutorialBtn = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.exitBtn = new System.Windows.Forms.PictureBox();
            this.newGameBtn = new System.Windows.Forms.PictureBox();
            this.continueBtn = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.tutorialBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exitBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.newGameBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.continueBtn)).BeginInit();
            this.SuspendLayout();
            // 
            // tutorialBtn
            // 
            this.tutorialBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.tutorialBtn.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.tutorial;
            this.tutorialBtn.Location = new System.Drawing.Point(377, 517);
            this.tutorialBtn.Margin = new System.Windows.Forms.Padding(4);
            this.tutorialBtn.Name = "tutorialBtn";
            this.tutorialBtn.Size = new System.Drawing.Size(453, 86);
            this.tutorialBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tutorialBtn.TabIndex = 36;
            this.tutorialBtn.TabStop = false;
            this.tutorialBtn.Click += new System.EventHandler(this.tutorialBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.pictureBox1.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(123, 123);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(944, 86);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // exitBtn
            // 
            this.exitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.exitBtn.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.exit;
            this.exitBtn.Location = new System.Drawing.Point(377, 641);
            this.exitBtn.Margin = new System.Windows.Forms.Padding(4);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(453, 86);
            this.exitBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exitBtn.TabIndex = 34;
            this.exitBtn.TabStop = false;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // newGameBtn
            // 
            this.newGameBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.newGameBtn.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.newGame;
            this.newGameBtn.Location = new System.Drawing.Point(377, 272);
            this.newGameBtn.Margin = new System.Windows.Forms.Padding(4);
            this.newGameBtn.Name = "newGameBtn";
            this.newGameBtn.Size = new System.Drawing.Size(453, 86);
            this.newGameBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.newGameBtn.TabIndex = 33;
            this.newGameBtn.TabStop = false;
            this.newGameBtn.Click += new System.EventHandler(this.newGameBtn_Click);
            // 
            // continueBtn
            // 
            this.continueBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.continueBtn.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources._continue;
            this.continueBtn.Location = new System.Drawing.Point(377, 396);
            this.continueBtn.Margin = new System.Windows.Forms.Padding(4);
            this.continueBtn.Name = "continueBtn";
            this.continueBtn.Size = new System.Drawing.Size(453, 86);
            this.continueBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.continueBtn.TabIndex = 32;
            this.continueBtn.TabStop = false;
            this.continueBtn.Click += new System.EventHandler(this.continueBtn_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.ClientSize = new System.Drawing.Size(1232, 814);
            this.Controls.Add(this.tutorialBtn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.newGameBtn);
            this.Controls.Add(this.continueBtn);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainMenu";
            this.ShowIcon = false;
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.MainMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tutorialBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exitBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.newGameBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.continueBtn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox continueBtn;
        private System.Windows.Forms.PictureBox newGameBtn;
        private System.Windows.Forms.PictureBox exitBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox tutorialBtn;
    }
}