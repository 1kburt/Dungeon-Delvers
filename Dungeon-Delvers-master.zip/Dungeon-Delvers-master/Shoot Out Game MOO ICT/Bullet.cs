﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Drawing;
using System.Windows.Forms;

namespace Shoot_Out_Game_MOO_ICT
{
    class Bullet
    {
        public string direction;
        public string shooter;
        public int bulletLeft;
        public int bulletTop;
        public static int weaponCooldown;
        public static double damage;
        public static int windowSize1;
        public static int windowSize2;
        public static string gunType; //change later
        public static bool BulletHitsPlayer;
        private int speed = 15;
        private PictureBox bullet = new PictureBox();
        private Timer bulletTimer = new Timer();


        public void MakeBullet(Form form)
        {


            if (gunType == "spacegun")
            {
                bullet.BackColor = Color.LimeGreen;
                bullet.Size = new Size(10, 10);
                //medium cooldown medium damage
                weaponCooldown = 15;
                damage = 30;
            }
            else if (gunType == "beeg")
            {
                bullet.BackColor = Color.Red;
                bullet.Size = new Size(20, 20);
                speed = 5;
                damage = 60;
                weaponCooldown = 50;
                //slow cooldown high damage
            }
            else if (gunType == "SPEED")
            {
                bullet.BackColor = Color.Yellow;
                bullet.Size = new Size(5, 5);
                speed = 30;
                damage = 10;
                weaponCooldown = 5;
                //fast cooldown low damage
            }
            else if (gunType == "spread")
            {
                bullet.BackColor = Color.Purple;
                bullet.Size= new Size(10, 10);
                weaponCooldown = 25;
                damage = 35;
                //spawn 3 bullet afew spaces away from each other - slow cooldown
            }
            bullet.Tag = "bullet";
            bullet.Left = bulletLeft;
            bullet.Top = bulletTop;
            bullet.BringToFront();
            form.Controls.Add(bullet);
            if (shooter == "goblin")
            {
                BulletHitsPlayer = true;
            }
            else if (shooter == "player")
            {
                BulletHitsPlayer = false;
            }

            bulletTimer.Interval = speed;
            bulletTimer.Tick += new EventHandler(BulletTimerEvent);
            bulletTimer.Start();

        }

        private void BulletTimerEvent(object sender, EventArgs e)
        {
            if (direction == "rightup")
            {
                bullet.Top -= speed;
                bullet.Left += speed;
            }
            if (direction == "leftup")
            {
                bullet.Top -= speed;
                bullet.Left -= speed;
            }
            if (direction == "rightdown")
            {
                bullet.Top += speed;
                bullet.Left += speed;
            }
            if(direction == "leftdown")
            {
                bullet.Top += speed;
                bullet.Left -= speed;
            }
            if (direction == "left")
            {
                bullet.Left -= speed;
            }

            if (direction == "right")
            {
                bullet.Left += speed;
            }

            if (direction == "up")
            {
                bullet.Top -= speed;
            }

            if (direction == "down")
            {
                bullet.Top += speed;
            }


            if (bullet.Left < 10 || bullet.Left > windowSize1 || bullet.Top < 10 || bullet.Top > windowSize2)
            {
                bulletTimer.Stop();
                bulletTimer.Dispose();
                bullet.Dispose();
                bulletTimer = null;
                bullet = null;
            }



        }



    }
}
