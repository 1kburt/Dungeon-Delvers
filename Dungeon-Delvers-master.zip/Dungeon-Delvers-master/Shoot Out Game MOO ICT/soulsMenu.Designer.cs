﻿namespace Shoot_Out_Game_MOO_ICT
{
    partial class soulsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelSouls = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.soulIcon = new System.Windows.Forms.PictureBox();
            this.menuBtn = new System.Windows.Forms.PictureBox();
            this.continueBtn = new System.Windows.Forms.PictureBox();
            this.speechBubble = new System.Windows.Forms.PictureBox();
            this.invincibility = new System.Windows.Forms.PictureBox();
            this.luckyStart = new System.Windows.Forms.PictureBox();
            this.attackBoost = new System.Windows.Forms.PictureBox();
            this.healthBoost = new System.Windows.Forms.PictureBox();
            this.reaper = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.soulIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.continueBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.speechBubble)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invincibility)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luckyStart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.attackBoost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.healthBoost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reaper)).BeginInit();
            this.SuspendLayout();
            // 
            // labelSouls
            // 
            this.labelSouls.AutoSize = true;
            this.labelSouls.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.labelSouls.Font = new System.Drawing.Font("A Goblin Appears!", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSouls.ForeColor = System.Drawing.Color.White;
            this.labelSouls.Location = new System.Drawing.Point(76, 33);
            this.labelSouls.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSouls.Name = "labelSouls";
            this.labelSouls.Size = new System.Drawing.Size(87, 18);
            this.labelSouls.TabIndex = 5;
            this.labelSouls.Text = "souls";
            // 
            // soulIcon
            // 
            this.soulIcon.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.Soul;
            this.soulIcon.Location = new System.Drawing.Point(12, 12);
            this.soulIcon.Name = "soulIcon";
            this.soulIcon.Size = new System.Drawing.Size(57, 64);
            this.soulIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.soulIcon.TabIndex = 43;
            this.soulIcon.TabStop = false;
            // 
            // menuBtn
            // 
            this.menuBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.menuBtn.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.menuBtn;
            this.menuBtn.Location = new System.Drawing.Point(59, 184);
            this.menuBtn.Margin = new System.Windows.Forms.Padding(4);
            this.menuBtn.Name = "menuBtn";
            this.menuBtn.Size = new System.Drawing.Size(225, 46);
            this.menuBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menuBtn.TabIndex = 32;
            this.menuBtn.TabStop = false;
            this.menuBtn.Click += new System.EventHandler(this.menuBtn_Click);
            // 
            // continueBtn
            // 
            this.continueBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.continueBtn.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources._continue;
            this.continueBtn.Location = new System.Drawing.Point(59, 113);
            this.continueBtn.Margin = new System.Windows.Forms.Padding(4);
            this.continueBtn.Name = "continueBtn";
            this.continueBtn.Size = new System.Drawing.Size(225, 46);
            this.continueBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.continueBtn.TabIndex = 31;
            this.continueBtn.TabStop = false;
            this.continueBtn.Click += new System.EventHandler(this.continueBtn_Click);
            // 
            // speechBubble
            // 
            this.speechBubble.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.cannotAfford;
            this.speechBubble.Location = new System.Drawing.Point(76, 356);
            this.speechBubble.Margin = new System.Windows.Forms.Padding(4);
            this.speechBubble.Name = "speechBubble";
            this.speechBubble.Size = new System.Drawing.Size(717, 146);
            this.speechBubble.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.speechBubble.TabIndex = 7;
            this.speechBubble.TabStop = false;
            this.speechBubble.Click += new System.EventHandler(this.speechBubble_Click);
            // 
            // invincibility
            // 
            this.invincibility.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.Invincibility;
            this.invincibility.Location = new System.Drawing.Point(792, 516);
            this.invincibility.Margin = new System.Windows.Forms.Padding(4);
            this.invincibility.Name = "invincibility";
            this.invincibility.Size = new System.Drawing.Size(293, 271);
            this.invincibility.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.invincibility.TabIndex = 4;
            this.invincibility.TabStop = false;
            this.invincibility.Click += new System.EventHandler(this.invincibility_Click);
            // 
            // luckyStart
            // 
            this.luckyStart.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.luckyStart;
            this.luckyStart.Location = new System.Drawing.Point(388, 516);
            this.luckyStart.Margin = new System.Windows.Forms.Padding(4);
            this.luckyStart.Name = "luckyStart";
            this.luckyStart.Size = new System.Drawing.Size(293, 271);
            this.luckyStart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.luckyStart.TabIndex = 3;
            this.luckyStart.TabStop = false;
            this.luckyStart.Click += new System.EventHandler(this.luckyStart_Click);
            // 
            // attackBoost
            // 
            this.attackBoost.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.attackBoost;
            this.attackBoost.Location = new System.Drawing.Point(792, 52);
            this.attackBoost.Margin = new System.Windows.Forms.Padding(4);
            this.attackBoost.Name = "attackBoost";
            this.attackBoost.Size = new System.Drawing.Size(293, 271);
            this.attackBoost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.attackBoost.TabIndex = 2;
            this.attackBoost.TabStop = false;
            this.attackBoost.Click += new System.EventHandler(this.attackBoost_Click);
            // 
            // healthBoost
            // 
            this.healthBoost.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.HealthBoost;
            this.healthBoost.Location = new System.Drawing.Point(388, 52);
            this.healthBoost.Margin = new System.Windows.Forms.Padding(4);
            this.healthBoost.Name = "healthBoost";
            this.healthBoost.Size = new System.Drawing.Size(293, 271);
            this.healthBoost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.healthBoost.TabIndex = 1;
            this.healthBoost.TabStop = false;
            this.healthBoost.Click += new System.EventHandler(this.healthBoost_Click);
            // 
            // reaper
            // 
            this.reaper.Image = global::Shoot_Out_Game_MOO_ICT.Properties.Resources.Reaper;
            this.reaper.Location = new System.Drawing.Point(16, 507);
            this.reaper.Margin = new System.Windows.Forms.Padding(4);
            this.reaper.Name = "reaper";
            this.reaper.Size = new System.Drawing.Size(257, 204);
            this.reaper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.reaper.TabIndex = 0;
            this.reaper.TabStop = false;
            this.reaper.Click += new System.EventHandler(this.reaper_Click);
            // 
            // soulsMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.ClientSize = new System.Drawing.Size(1232, 814);
            this.Controls.Add(this.soulIcon);
            this.Controls.Add(this.menuBtn);
            this.Controls.Add(this.continueBtn);
            this.Controls.Add(this.speechBubble);
            this.Controls.Add(this.labelSouls);
            this.Controls.Add(this.invincibility);
            this.Controls.Add(this.luckyStart);
            this.Controls.Add(this.attackBoost);
            this.Controls.Add(this.healthBoost);
            this.Controls.Add(this.reaper);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "soulsMenu";
            this.ShowIcon = false;
            this.Text = "Sacrifice Souls";
            this.Load += new System.EventHandler(this.soulsMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.soulIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.continueBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.speechBubble)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invincibility)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luckyStart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.attackBoost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.healthBoost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reaper)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox reaper;
        private System.Windows.Forms.PictureBox healthBoost;
        private System.Windows.Forms.PictureBox attackBoost;
        private System.Windows.Forms.PictureBox luckyStart;
        private System.Windows.Forms.PictureBox invincibility;
        private System.Windows.Forms.Label labelSouls;
        private System.Windows.Forms.PictureBox speechBubble;
        private System.Windows.Forms.PictureBox continueBtn;
        private System.Windows.Forms.PictureBox menuBtn;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox soulIcon;
    }
}